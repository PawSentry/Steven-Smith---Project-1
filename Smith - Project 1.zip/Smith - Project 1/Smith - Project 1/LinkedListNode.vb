﻿Public Class LinkedListNode

End Class
