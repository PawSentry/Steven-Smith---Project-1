﻿Public Class Form1
    ' This program implements a stack using a linked list. The GUI will allow the user to push integers on the stack,
    ' and also pop integers off the stack.

    Private Sub btnPush_Click(sender As Object, e As EventArgs) Handles btnPush.Click
        ' Check if the input is a number and doesn't already exist in the stack.
        If IsNumeric(txtNumberToPush.Text) And Not lstStack.Items.Contains(txtNumberToPush.Text) Then
            ' A new number is pushed onto the top of the stack.
            lstStack.Items.Insert(0, txtNumberToPush.Text)
        Else
            ' This error message displays if the input is not a number or already exists in the stack.
            MessageBox.Show("Please enter a different number to push onto the stack.")
        End If
    End Sub

    Private Sub btnPop_Click(sender As Object, e As EventArgs) Handles btnPop.Click
        ' Check if there is a number to pop off of the stack.
        If lstStack.Items.Count > 0 Then
            ' The top number in the stack is popped off.
            lstStack.Items.RemoveAt(0)
        Else
            ' This error message displays if the stack is empty.
            MessageBox.Show("The stack has no numbers to pull.")
        End If
    End Sub




End Class
