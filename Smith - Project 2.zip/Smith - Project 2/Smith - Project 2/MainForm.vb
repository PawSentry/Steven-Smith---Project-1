﻿Public Class MainForm
    'I wrote a program that uses recursion on a linked list of 500 random integers to search for a user's chosen number,
    ' if it exists in the list.

    Private Sub btnFill_Click(sender As Object, e As EventArgs) Handles btnFill.Click
        Dim rand As New Random           ' Variable to generate the random values.
        Dim intMyRand As Integer         ' Variable to hold the random values.

        ' Empty the listbox of all numbers.
        clearList()

        ' Loop to fill in the listbox with random values.
        Do
            intMyRand = rand.Next(0, 10000000)
            lstIntegers.Items.Add(intMyRand.ToString())
        Loop While lstIntegers.Items.Count < 500

        txtNumber.Enabled = True                                ' Enable this text box so the user can type in a number to search for in the listbox.
        btnSearch.Enabled = True                                ' Enable this button so the user can search for their selected number in the listbox.
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        ' Empty the listbox of all numbers.
        clearList()

        ' Disable this text box and button so the user does not try looking for a value in the empty list box.
        txtNumber.Enabled = False
        btnSearch.Enabled = False

        ' Clear this text box of its contents.
        txtNumber.Text = String.Empty

        ' Clear the Status Strip of its contents.
        lblMessage.Text = String.Empty
    End Sub

    Private Sub clearList()
        lstIntegers.Items.Clear()
    End Sub

    Private Sub mnuFileExit_Click(sender As Object, e As EventArgs) Handles mnuFileExit.Click
        ' Leave the application.
        Me.Close()
    End Sub

    Private Sub btnSearch_Click(sender As Object, e As EventArgs) Handles btnSearch.Click
        Dim i As Integer = 0                                                 ' Variable to hold the current index number for the list

        If i < lstIntegers.Items.Count Then                                  ' This loop sets the conditions for the recursive Call subroutine.
            Call search(i)                                                   ' Recursive subroutine to search through the listbox for the user's number.
        End If
    End Sub

    Sub search(ByRef i As Integer)
        ' This loop checks if the user's number exists in the list.
        While i <= lstIntegers.Items.Count - 1
            If lstIntegers.Items(i) = txtNumber.Text Then
                ' This message displays if the subroutine has found a match.
                lblMessage.Text = "Your number, " + txtNumber.Text + ", exists in the list."
                Exit Sub
            Else
                i = i + 1          ' This variable if incremented so the loop will move onto the next number in the list.
                search(i)          ' The recursive call for this subroutine
            End If
        End While

        If i = lstIntegers.Items.Count Then
            ' This message displays if the subroutine has gone through all the numbers in the list without finding a match.
            lblMessage.Text = "Your number could not be found in the list."
        End If
    End Sub
End Class
