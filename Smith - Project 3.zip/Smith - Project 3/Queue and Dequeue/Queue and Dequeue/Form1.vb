﻿Public Class Form1
    ' I wrote a program that uses a queue via a linked list. Users can both enqueue and dequeue integers off the queue
    ' as much they want, but they can only dequeue so long as the list has numbers in it. No built-in queues
    ' or linked lists were incoporated into the desing of this program.

    Private Sub mnuFileExit_Click(sender As Object, e As EventArgs) Handles mnuFileExit.Click
        ' Close the application.
        Me.Close()
    End Sub

    Private Sub btnEnqueue_Click(sender As Object, e As EventArgs) Handles btnEnqueue.Click
        ' Checks if the input is an integer not already in the queue.
        If IsNumeric(txtNumber.Text) And Not lstIntegers.Items.Contains(txtNumber.Text) Then
            ' Add in the next integer.
            lstIntegers.Items.Insert(0, txtNumber.Text)

            ' Clears the message strip.
            lblMessage.Text = String.Empty
        Else
            ' This message displays if the input is not an integer or is already in the queue.
            lblMessage.Text = "Please enter a new integer into the textbox."
            lblMessage.ForeColor = Color.Red
        End If
    End Sub

    Private Sub btnDequeue_Click(sender As Object, e As EventArgs) Handles btnDequeue.Click
        ' Checks if the queue is empty.
        If lstIntegers.Items.Count > 0 Then
            ' Removes the first integer added to the queue.
            lstIntegers.Items.RemoveAt(lstIntegers.Items.Count - 1)

            ' Clears the message strip.
            lblMessage.Text = String.Empty
        Else
            ' This message displays if the queue is empty.
            lblMessage.Text = "The queue is empty. You cannot dequeue any further."
            lblMessage.ForeColor = Color.Red
        End If
    End Sub
End Class
