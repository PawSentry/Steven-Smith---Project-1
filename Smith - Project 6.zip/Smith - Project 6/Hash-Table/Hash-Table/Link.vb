﻿Public Class Link
    Public strWord As String                        ' Holds the word to serve as the key
    Public intCount As Integer = 1                 ' Holds the word count to serve as the value

    Sub New(ByVal strData As String, ByVal intWordCount As Integer)   ' Constructor for the word and word count
        strWord = strData
        intCount = intWordCount
    End Sub
End Class
