﻿Imports System
Imports System.IO
Imports System.Collections

Public Class MainForm
    ' I used a built-in hash table to record each word in a text document
    ' and the number of times each one occurs. After scanning the document 
    ' and parsing each word, I took away all punctuation and made all words lower case.
    ' Then, I added each word to the table one by one.  If the word was already in the table, 
    ' I incremented the counter; if not, I added the new word to the hash table 
    ' and reset the counter to one. Finally, once the hash table was completed, 
    ' I allowed the user to input a word in order to see if it exists in the table.

    Dim words As Array                                                        ' Array to hold the parsed words from the text document
    Dim intPointer As Integer = 0                                             ' Pointer index for current word in the array
    Dim intNumTimes As Integer = 1                                            ' Counter for the number of times each word occurs
    Dim htHashTable As New Hashtable()                                        ' A hash table to hold the words as keys and their counts as values

    Private Sub MainForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Try-Catch statement to handle the text reader
        Try
            Dim readFile As StreamReader = New StreamReader("Text-Document.txt")       ' Variable to write down the file content
            Dim file As String                                                         ' Variable to hold the file content

            file = readFile.ReadToEnd()                                                ' Retrieves the entire file
            file = file.ToLower                                                        ' String is converted to all lowercase letter
            file = Replace(file, "-", " ")                                             ' String is stripped of all hyphens
            file = Replace(file, ",", "")                                              ' String is stripped of all commas
            file = Replace(file, ".", "")                                              ' String is stripped of all periods
            file = Replace(file, "'", "")                                              ' String is stripped of all single quotation marks
            file = Replace(file, """", "")                                             ' String is stripped of all double quotation marks
            file = Replace(file, "?", "")                                              ' String is stripped of all question marks
            file = Replace(file, vbCrLf, " ")                                          ' String is stripped of all new lines

            words = file.Split(" ")                                                    ' The file contents are converted into an array.

            readFile.Close()                                                           ' The file closes.

            ' This While loop will add the document's words to the hash table.
            While intPointer < words.Length
                If htHashTable.ContainsKey(words(intPointer)) Then
                    intNumTimes = htHashTable.Item(words(intPointer)) + 1       ' Increment the word count for this key
                    Dim Link = New Link(words(intPointer), intNumTimes)         ' Create a new key with a new count
                    htHashTable.Remove(Link.strWord)                            ' Remove the current value and its key
                    htHashTable.Add(Link.strWord, Link.intCount)                ' Substitute with the same key and its new incremented value
                Else
                    Dim Link = New Link(words(intPointer), intNumTimes)         ' Create a new key and start its count at 1
                    htHashTable.Add(Link.strWord, Link.intCount)                ' Add that new key and its count to the table
                End If

                intPointer += 1                 ' Move onto next value in the array
            End While

        Catch ex As Exception
            ' This message displays if the file does not exist.
            MessageBox.Show("The file could not be found. Please check the file's name and try again.")
        End Try
    End Sub

    Private Sub btnCheck_Click(sender As Object, e As EventArgs) Handles btnCheck.Click
        ' This If-Else statement checks if the user entered anything into the text box.
        If txtInput.Text <> "" Then
            ' This If-Else statement checks if the user's inputted word exists in the hashtable.
            If htHashTable.ContainsKey(LCase(txtInput.Text)) Then
                lblMessage.Text = "Yes, this word exists in the hash table!"                       ' Message to confirm the word exists in the hash table.
            Else
                lblMessage.Text = "Sorry, but this word does not exist in the hash table."    ' Message to confirm the words does not exist in the hash table.
            End If
        Else
            lblMessage.Text = "Please enter a string into the text box."                ' Message to confirm the user did not enter any input
        End If
    End Sub

    Private Sub mnuFileExit_Click(sender As Object, e As EventArgs) Handles mnuFileExit.Click
        'Close the file.
        Me.Close()
    End Sub
End Class
