﻿Public Class TrilinkTree
    Private root As New Node                                                    ' The first node of the Trilink tree
    Private temp As Integer                                                     ' Variable to hold the current value
    Private strItem As String                                                   ' Variable to hold the item to be printed

    Public colTree As New Collection                                            ' This collection will hold the tree items so they can be printed later.

    Public intCountOneNode As Integer = 0                                       ' Variable for the number of nodes with only one value
    Public intCountTwoNode As Integer = 0                                       ' Variable for the number of nodes with two values

    Public Sub Insert(intValue As Integer)
        temp = New Integer
        temp = intValue

        If root.NodeArray(0) = Nothing Then
            root.NodeArray(0) = temp                                                ' Insert first value for node
        ElseIf root.NodeArray(1) = Nothing And temp > root.NodeArray(0) Then
            root.NodeArray(1) = temp                                                ' Insert second value for node
        ElseIf root.NodeArray(0) = temp Then
            root.blnDeletedFirstValue = False                                       ' Undo delete of first node value
        ElseIf root.NodeArray(1) = temp Then
            root.blnDeletedSecondValue = False                                      ' Undo delete of second node value
        Else
            recInsert(root)                                                         ' Call this subroutine to recurse down the tree
        End If
    End Sub

    Public Sub recInsert(currentNode As Node)
        Dim newNode As New Node                   ' Create a new node for when a child node has nothing.

        ' This If-Else loop will check if the value already exists in the node
        If currentNode.NodeArray(0) = temp And currentNode.blnDeletedFirstValue = True Then
            currentNode.blnDeletedFirstValue = False                                    ' Undo delete of first value
            Exit Sub
        ElseIf currentNode.NodeArray(1) = temp And currentNode.blnDeletedSecondValue = True Then
            currentNode.blnDeletedSecondValue = False                                   ' Undo delete of second value
            Exit Sub
        End If

        If temp < currentNode.NodeArray(0) Then                   ' If the input is less than the first node value
            If currentNode.LeftChild Is Nothing Then
                currentNode.LeftChild = newNode                         ' Create the current node's left child
                currentNode.LeftChild.NodeArray(0) = temp              ' Add the first node value to the left child
            ElseIf currentNode.LeftChild.NodeArray(1) = Nothing And temp > currentNode.LeftChild.NodeArray(0) Then
                currentNode.LeftChild.NodeArray(1) = temp              ' Add the second node value to the left child
            ElseIf temp < currentNode.LeftChild.NodeArray(0) Then
                If currentNode.LeftChild.LeftChild Is Nothing Then
                    currentNode.LeftChild.LeftChild = newNode               ' Create the left child of the current node's left child
                    currentNode.LeftChild.LeftChild.NodeArray(0) = temp
                Else
                    recInsert(currentNode.LeftChild.LeftChild)                       ' Recurse the left child's left child as the current node
                End If
            ElseIf temp = currentNode.LeftChild.NodeArray(0) Then
                recInsert(currentNode.LeftChild)                                    ' Recurse the left child to undo the delete
            ElseIf currentNode.LeftChild.NodeArray(1) <> Nothing Then
                If temp > currentNode.LeftChild.NodeArray(0) And temp < currentNode.LeftChild.NodeArray(1) Then
                    If currentNode.LeftChild.MiddleChild Is Nothing Then
                        currentNode.LeftChild.MiddleChild = newNode                     ' Create the middle child of the current node's left child
                        currentNode.LeftChild.MiddleChild.NodeArray(0) = temp
                    Else
                        recInsert(currentNode.LeftChild.MiddleChild)                       ' Recurse the middle child as the current node
                    End If
                ElseIf temp = currentNode.LeftChild.NodeArray(1) Then
                    recInsert(currentNode.LeftChild)                                      ' Recurse the left child to undo the delete
                ElseIf temp > currentNode.LeftChild.NodeArray(1) Then
                    If currentNode.LeftChild.RightChild Is Nothing Then
                        currentNode.LeftChild.RightChild = newNode                          ' Create the right child of the current node's left child
                        currentNode.LeftChild.RightChild.NodeArray(0) = temp
                    Else
                        recInsert(currentNode.LeftChild.RightChild)                       ' Recurse the right child as the current node
                    End If
                End If
            End If

        ElseIf currentNode.NodeArray(1) = Nothing And temp > currentNode.NodeArray(0) Then      ' Fill the second value of the node
            currentNode.NodeArray(1) = temp

        ElseIf currentNode.NodeArray(1) <> Nothing And (temp > currentNode.NodeArray(0) And temp < currentNode.NodeArray(1)) Then

            If currentNode.MiddleChild Is Nothing Then
                currentNode.MiddleChild = newNode                           ' Create the middle child of the current node
                currentNode.MiddleChild.NodeArray(0) = temp              ' Add V1 to left child
            ElseIf currentNode.MiddleChild.NodeArray(1) = Nothing And temp > currentNode.MiddleChild.NodeArray(0) Then
                currentNode.MiddleChild.NodeArray(1) = temp              ' Add V2 to left child
            ElseIf temp < currentNode.MiddleChild.NodeArray(0) Then
                If currentNode.MiddleChild.LeftChild Is Nothing Then
                    currentNode.MiddleChild.LeftChild = newNode                 ' Create the left child of the current node's middle child
                    currentNode.MiddleChild.LeftChild.NodeArray(0) = temp
                Else
                    recInsert(currentNode.MiddleChild.LeftChild)                       ' Recurse the middle child's left child as the current node
                End If
            ElseIf temp = currentNode.MiddleChild.NodeArray(0) Then
                recInsert(currentNode.MiddleChild)                                      ' Recurse the middle child to undo the delete
            ElseIf currentNode.MiddleChild.NodeArray(1) <> Nothing Then
                If temp > currentNode.MiddleChild.NodeArray(0) And temp < currentNode.MiddleChild.NodeArray(1) Then
                    If currentNode.MiddleChild.MiddleChild Is Nothing Then
                        currentNode.MiddleChild.MiddleChild = newNode                       ' Create the middle child of the current node's middle child
                        currentNode.MiddleChild.MiddleChild.NodeArray(0) = temp
                    Else
                        recInsert(currentNode.MiddleChild.MiddleChild)                       ' Recurse the middle child as the current node
                    End If
                ElseIf temp = currentNode.MiddleChild.NodeArray(1) Then
                    recInsert(currentNode.MiddleChild)                                     ' Recurse the middle child to undo the delete
                ElseIf temp > currentNode.MiddleChild.NodeArray(1) Then
                    If currentNode.MiddleChild.RightChild Is Nothing Then
                        currentNode.MiddleChild.RightChild = newNode                        ' Create the right child of the current node's middle child
                        currentNode.MiddleChild.RightChild.NodeArray(0) = temp
                    Else
                        recInsert(currentNode.MiddleChild.RightChild)                       ' Recurse the right child as the current node
                    End If
                End If
            End If

        ElseIf currentNode.NodeArray(1) <> Nothing And temp > currentNode.NodeArray(1) Then                        ' Only if the second value is not nothing
            If currentNode.RightChild Is Nothing Then
                currentNode.RightChild = newNode                                ' Create the right child of the current node
                currentNode.RightChild.NodeArray(0) = temp                      ' Add the input to the right child's first node value
            ElseIf currentNode.RightChild.NodeArray(1) = Nothing And temp > currentNode.RightChild.NodeArray(0) Then
                currentNode.RightChild.NodeArray(1) = temp                              ' Add the input to right child's second node value
            ElseIf temp < currentNode.RightChild.NodeArray(0) Then
                If currentNode.RightChild.LeftChild Is Nothing Then
                    currentNode.RightChild.LeftChild = newNode                      ' Create the left child of the current node's right child
                    currentNode.RightChild.LeftChild.NodeArray(0) = temp
                Else
                    recInsert(currentNode.RightChild.LeftChild)                       ' Recurse the left child as the current node
                End If
            ElseIf temp = currentNode.RightChild.NodeArray(0) Then
                recInsert(currentNode.RightChild)                                       ' Recurse the middle child to undo the delete
            ElseIf currentNode.RightChild.NodeArray(1) <> Nothing Then
                If temp > currentNode.RightChild.NodeArray(0) And temp < currentNode.RightChild.NodeArray(1) Then
                    If currentNode.RightChild.MiddleChild Is Nothing Then
                        currentNode.RightChild.MiddleChild = newNode                    ' Create the middle child of the current node's right child
                        currentNode.RightChild.MiddleChild.NodeArray(0) = temp
                    Else
                        recInsert(currentNode.RightChild.MiddleChild)                       ' Recurse the middle child as the current node
                    End If
                ElseIf temp > currentNode.RightChild.NodeArray(1) Then
                    If currentNode.RightChild.RightChild Is Nothing Then
                        currentNode.RightChild.RightChild = newNode                         ' Create the right child of the current node's right child
                        currentNode.RightChild.RightChild.NodeArray(0) = temp
                    Else
                        recInsert(currentNode.RightChild.RightChild)                       ' Recurse the right child as the current node
                    End If
                ElseIf temp = currentNode.RightChild.NodeArray(1) Then
                    recInsert(currentNode.RightChild)                                       ' Recurse the right child to undo the delete
                End If
            End If
        End If
    End Sub

    Public Sub Find(intValue As Integer, ByRef blFound As Boolean)
        temp = New Integer
        temp = intValue

        If temp = root.NodeArray(0) Then                ' If the input is the root's first value
            blFound = True
            Exit Sub
        ElseIf temp = root.NodeArray(1) Then            ' If the input is the root's second value
            blFound = True
            Exit Sub
        Else
            recFind(root, blFound)                      ' Recurse into the other nodes of the tree
        End If
    End Sub

    Public Sub recFind(currentNode As Node, ByRef blFound As Boolean)
        ' Check if the current node's first value exists and not deleted
        If temp = currentNode.NodeArray(0) And currentNode.blnDeletedFirstValue = False Then
            blFound = True
            Exit Sub
        ElseIf temp < currentNode.NodeArray(0) And currentNode.LeftChild IsNot Nothing Then
            recFind(currentNode.LeftChild, blFound)
        ElseIf temp > currentNode.NodeArray(0) And currentNode.NodeArray(1) = Nothing Then
            Exit Sub                             ' Leave if the input is greater than the first node value but there's no second node value
        End If

        ' Check if the current node's second value is deleted
        If currentNode.NodeArray(1) <> Nothing And currentNode.blnDeletedSecondValue = False Then
            If temp = currentNode.NodeArray(1) Then
                blFound = True
            ElseIf temp > currentNode.NodeArray(0) And temp < currentNode.NodeArray(1) And currentNode.MiddleChild IsNot Nothing Then
                recFind(currentNode.MiddleChild, blFound)
            ElseIf temp > currentNode.NodeArray(1) And currentNode.RightChild IsNot Nothing Then
                recFind(currentNode.RightChild, blFound)
            Else
                Exit Sub                         ' Leave if the input is greater than the second node value but there's no child left
            End If
        End If
    End Sub

    Public Sub Print()
        recPrint(root)
    End Sub

    Public Sub recPrint(currentNode As Node)

        ' If the current node's left node does not have a null value
        If currentNode.LeftChild IsNot Nothing Then
            ' Recurse the left node as the current node
            recPrint(currentNode.LeftChild)
        End If

        ' If current node does not have a null value adn that its first value is not deleted
        If currentNode IsNot Nothing And currentNode.blnDeletedFirstValue = False Then
            ' Add this value to the list for display
            strItem = currentNode.NodeArray(0).ToString
            colTree.Add(strItem)
        End If

        ' If the current node's right node does not have a null value
        If currentNode.MiddleChild IsNot Nothing Then
            ' Recurse the right node as the current node
            recPrint(currentNode.MiddleChild)
        End If

        ' If current node does not have a null value adn that its second value is not deleted
        If currentNode.NodeArray(1) <> Nothing And currentNode.blnDeletedSecondValue = False Then
            strItem = currentNode.NodeArray(1).ToString
            colTree.Add(strItem)
        End If

        ' If the current node's right node does not have a null value
        If currentNode.RightChild IsNot Nothing Then
            ' Recurse the right node as the current node
            recPrint(currentNode.RightChild)
        End If
    End Sub

    Public Sub CountNodes()
        recCountNodes(root)
    End Sub

    Public Sub recCountNodes(currentNode As Node)
        ' Examine if the node has only one value
        If currentNode.NodeArray(0) <> Nothing And currentNode.NodeArray(1) = Nothing Then
            If currentNode.blnDeletedFirstValue = False Then                ' If the first value is not deleted
                intCountOneNode += 1                                        ' Increment the number of nodes with only one value
            End If
        End If

        ' Examine if the node has two values
        If currentNode.NodeArray(0) <> Nothing And currentNode.NodeArray(1) <> Nothing Then
            If currentNode.blnDeletedFirstValue = False And currentNode.blnDeletedSecondValue = False Then         ' If both values are not deleted
                intCountTwoNode += 1                                                                               ' Increment the number of nodes with two values
            ElseIf currentNode.blnDeletedFirstValue = False Or currentNode.blnDeletedSecondValue = False Then      ' If only one value is deleted
                intCountOneNode += 1                                                                               ' Increment the number of nodes with only one value
            End If
        End If

        ' If the current node's left node does not have a null value
        If currentNode.LeftChild IsNot Nothing Then
            ' Recurse the left node as the current node
            recCountNodes(currentNode.LeftChild)
        End If

        ' If the current node's right node does not have a null value
        If currentNode.MiddleChild IsNot Nothing Then
            ' Recurse the right node as the current node
            recCountNodes(currentNode.MiddleChild)
        End If

        ' If the current node's right node does not have a null value
        If currentNode.RightChild IsNot Nothing Then
            ' Recurse the right node as the current node
            recCountNodes(currentNode.RightChild)
        End If
    End Sub

    Public Sub Delete(intValue As Integer, ByRef blnFound As Boolean)
        recDelete(root, intValue, blnFound)
    End Sub

    Public Sub recDelete(currentNode As Node, intValue As Integer, ByRef blnFound As Boolean)

        If currentNode.NodeArray(0) = intValue Then                 ' If the value to be deleted is the first node value
            currentNode.blnDeletedFirstValue = True                 ' Set the delete flag for the first node value to true
            blnFound = currentNode.blnDeletedFirstValue
            Exit Sub
        ElseIf currentNode.NodeArray(1) = intValue Then             ' If the value to be deleted is the second node value
            currentNode.blnDeletedSecondValue = True                ' Set the delete flag for the second node value to true
            blnFound = currentNode.blnDeletedSecondValue
            Exit Sub
        End If

        ' If the current node's left node does not have a null value
        If currentNode.LeftChild IsNot Nothing Then
            ' Recurse the left node as the current node
            recDelete(currentNode.LeftChild, intValue, blnFound)
        End If

        ' If the current node's right node does not have a null value
        If currentNode.MiddleChild IsNot Nothing Then
            ' Recurse the right node as the current node
            recDelete(currentNode.MiddleChild, intValue, blnFound)
        End If

        ' If the current node's right node does not have a null value
        If currentNode.RightChild IsNot Nothing Then
            ' Recurse the right node as the current node
            recDelete(currentNode.RightChild, intValue, blnFound)
        End If
    End Sub
End Class
