﻿Public Class Node
    Public LeftChild As Node                            ' This variable will act as the current node's left child
    Public MiddleChild As Node                          ' This variable will act as the current node's middle child
    Public RightChild As Node                           ' This variable will act as the current node's right child

    Public NodeArray(1) As Integer                      ' This array will hold the values for each node

    Public blnDeletedFirstValue As Boolean = False      ' This flag will tell whether the first node value is deleted
    Public blnDeletedSecondValue As Boolean = False     ' This flag will tell whether the second node value is deleted
End Class
