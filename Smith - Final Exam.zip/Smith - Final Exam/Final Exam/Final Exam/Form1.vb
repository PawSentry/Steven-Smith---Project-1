﻿Public Class Form1
    Dim Trilink As New TrilinkTree              ' This variable will act as the Trilink tree for all entered node values
    Dim blnFound As Boolean = False              ' This Boolean value will serve as a flag when finding node values

    Private Sub mnuFileExit_Click(sender As Object, e As EventArgs) Handles mnuFileExit.Click
        'Close the form.
        Me.Close()
    End Sub

    Private Sub btnEnter_Click(sender As Object, e As EventArgs) Handles btnEnter.Click
        ' This If-Else statement will check if the input is a nonzero integer.
        If IsNumeric(txtInput.Text) = True Then
            If txtInput.Text <> 0 Then
                Trilink.Insert(txtInput.Text)                       ' Call the function to insert the new value into the Trilink tree.
                lblMessage.Text = "The integer has been inserted."        ' This message will display if the input is not an integer.
            Else
                lblMessage.Text = "Please enter a nonzero integer."        ' This message will display if the input is not an integer.
            End If
        Else
            lblMessage.Text = "Please enter a nonzero integer."        ' This message will display if the input is not an integer.
        End If
    End Sub

    Private Sub btnFind_Click(sender As Object, e As EventArgs) Handles btnFind.Click
        ' The Boolean flag is reset for the next value the user will search for.
        blnFound = False

        ' This If-Else statement will check if the input is an integer.
        If IsNumeric(txtInput.Text) = True Then
            If txtInput.Text <> 0 Then
                Trilink.Find(txtInput.Text, blnFound)                ' Call the function to search for the input in the tree.
                If blnFound = True Then
                    lblMessage.Text = "Number found."               ' The message for when the input is found in the tree.
                Else
                    lblMessage.Text = "Number not found."           ' The message for when the input is not found in the tree.
                End If
            Else
                lblMessage.Text = "Please enter a nonzero integer."         ' The message for when the input is not an integer.
            End If
        Else
            lblMessage.Text = "Please enter a nonzero integer."        ' This message will display if the input is not an integer.
        End If
    End Sub

    Private Sub btnPrint_Click(sender As Object, e As EventArgs) Handles btnPrint.Click
        Trilink.colTree.Clear()                             ' Remove the previous contents from the collection
        lstOutput.Items.Clear()                             ' Clear the previous contents from the listbox

        ' This If-Else statement will check if the input is a nonzero integer.
        If IsNumeric(txtInput.Text) = True Then
            If txtInput.Text <> 0 Then
                Trilink.Print()                                     ' Print the node values into the collection

                ' This For Next loop will display the node values in the listbox
                For j = 1 To Trilink.colTree.Count
                    lstOutput.Items.Add(Trilink.colTree.Item(j))    ' Adds each value of the Trilink tree to the listbox
                Next
            Else
                lblMessage.Text = "Please enter a nonzero integer."         ' The message for when the input is not an integer.
            End If
        Else
            lblMessage.Text = "Please enter a nonzero integer."        ' This message will display if the input is not an integer.
        End If
    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        ' This If-Else statement will check if the input is a nonzero integer.
        If IsNumeric(txtInput.Text) = True Then
            If txtInput.Text <> 0 Then
                Trilink.Delete(txtInput.Text, blnFound)                     ' Call the function to delete the input number from the tree

                ' This If-Else statement will happen if the value to be deleted has been found.
                If blnFound = True Then
                    lblMessage.Text = "This value has been deleted."
                Else
                    lblMessage.Text = "This value either does not exist in the tree or has already been deleted."
                End If
            Else
                lblMessage.Text = "Please enter a nonzero integer."        ' This message will display if the input is not an integer.
            End If
        Else
            lblMessage.Text = "Please enter a nonzero integer."        ' This message will display if the input is not an integer.
        End If
    End Sub

    Private Sub btnCountNodes_Click(sender As Object, e As EventArgs) Handles btnCountNodes.Click
        ' Clear both textboxes of previous contents.
        lblNodesOne.Text = String.Empty
        lblNodesTwo.Text = String.Empty

        ' Reset the node value counts
        Trilink.intCountOneNode = 0
        Trilink.intCountTwoNode = 0

        Trilink.CountNodes()            ' Call the function to count the number of nodes with either one or two values

        lblNodesOne.Text = Trilink.intCountOneNode.ToString         ' Display the number of nodes with one value
        lblNodesTwo.Text = Trilink.intCountTwoNode.ToString         ' Display the number of nodes with two values
    End Sub
End Class
