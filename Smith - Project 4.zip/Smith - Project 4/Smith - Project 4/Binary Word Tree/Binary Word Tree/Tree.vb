﻿Imports System
Imports System.IO

Public Class Tree
    ' I created a modified binary tree to record each word in a text document
    ' and the number of times each one occurs. After scanning the document 
    ' and parsing each word, I took away all punctuation and made all words lower case.
    ' Then, I added each word to the tree one by one.  If the word was already in the tree, 
    ' I incremented the counter; if not, I added the new word to the B-Tree 
    ' and reset the counter to one. Finally, once the binary tree was completed, 
    ' I used in-order traversal to print the words in alphabetical order along with the word count.

    Dim words As Array                                                                 ' Array to hold the parsed words from the text document
    Dim i As Integer = 0                                                               ' Pointer index for current word in the array
    Private root As TreeNode                                                           ' Variable to serve as the root for the binary tree
    Private temp As TreeNode                                                           ' Variable to hold the new node value for the tree

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Try-Catch statement to handle the text reader
        Try
            Dim readFile As StreamReader = New StreamReader("Text-Document.txt")       ' Variable to write down the file content
            Dim file As String                                                         ' Variable to hold the file content

            file = readFile.ReadToEnd()                                                ' Retrieves the entire file
            file = file.ToLower                                                        ' String is converted to all lowercase letter
            file = Replace(file, "-", " ")                                             ' String is stripped of all hyphens
            file = Replace(file, ",", "")                                              ' String is stripped of all commas
            file = Replace(file, ".", "")                                              ' String is stripped of all periods
            file = Replace(file, "'", "")                                              ' String is stripped of all single quotation marks
            file = Replace(file, """", "")                                             ' String is stripped of all double quotation marks
            file = Replace(file, "?", "")                                              ' String is stripped of all question marks
            file = Replace(file, vbCrLf, " ")                                          ' String is stripped of all new lines

            words = file.Split(" ")                                                    ' The file contents are converted into an array.

            readFile.Close()                                                           ' The file closes.

            ' This While loop will add the document's words to the binary tree.
            While i < words.Length
                Call AddNode(words(i))
                i += 1                              ' Increment to the next word in the array
            End While

        Catch ex As Exception
            ' This message displays if the file does not exist.
            MessageBox.Show("The file could not be found. Please check the file's name and try again.")
        End Try
    End Sub

    Private Sub mnuFileExit_Click(sender As Object, e As EventArgs) Handles mnuFileExit.Click
        'Close the application.
        Me.Close()
    End Sub

    Private Sub btnDisplayCount_Click(sender As Object, e As EventArgs) Handles btnDisplayCount.Click
        ' Clear the list of the previous contents
        lstTree.Items.Clear()

        recPrint(root)

        ' Remove the topmost element in the list (the number of new lines)
        lstTree.Items.RemoveAt(0)
    End Sub

    ' This subroutine will fill the root with a value then call the recurse subroutine to fill the rest of the tree.
    Public Sub AddNode(nodeValue As Object)
        temp = New TreeNode                         ' Temporary variable becomes the new tree node.
        temp.Value = nodeValue                      ' Temporary variable gets the parameter's value

        ' If the root has a null value
        If root Is Nothing Then
            ' Give the root the temporary value
            root = temp
        Else
            ' Or move onto the other nodes
            recAdd(root)
        End If
    End Sub

    ' This subroutine will recurse to fill the binary tree with new nodes and count each duplicate value.
    Private Sub recAdd(currentNode As TreeNode)
        ' If the temporary node value is less than the current node value
        If String.Compare(temp.Value, currentNode.Value) < 0 Then

            ' If the current node's left node has a null value
            If currentNode.LeftChild Is Nothing Then
                currentNode.LeftChild = temp                            ' A new node is added as the left child
                currentNode.WordCount = 1                               ' Reset the word counter
            Else
                ' Recurse the left node as the current node
                recAdd(currentNode.LeftChild)
            End If
        Else
            ' If the temporary node value is greater than the current node value
            If String.Compare(temp.Value, currentNode.Value) > 0 Then

                ' If the current node's right node has a null value
                If currentNode.RightChild Is Nothing Then
                    currentNode.RightChild = temp                       ' A new node is added as the right child
                    currentNode.WordCount = 1                           ' Reset the word counter
                Else
                    ' Recurse the right node as the current node
                    recAdd(currentNode.RightChild)
                End If
            Else
                ' Duplicate values are counted.
                currentNode.WordCount += 1
            End If
        End If
    End Sub

    ' This subroutine will use inorder traversal to display the binary tree's node values in the list.
    Public Sub recPrint(currentNode As TreeNode)
        ' If the current node's left node does not have a null value
        If currentNode.LeftChild IsNot Nothing Then
            ' Recurse the left node as the current node
            recPrint(currentNode.LeftChild)
        End If

        ' If current node does not have a null value
        If currentNode IsNot Nothing Then
            ' Add this value to the list for display
            lstTree.Items.Add(currentNode.Value + ": " + currentNode.WordCount.ToString)
        End If

        ' If the current node's right node does not have a null value
        If currentNode.RightChild IsNot Nothing Then
            ' Recurse the right node as the current node
            recPrint(currentNode.RightChild)
        End If
    End Sub
End Class
