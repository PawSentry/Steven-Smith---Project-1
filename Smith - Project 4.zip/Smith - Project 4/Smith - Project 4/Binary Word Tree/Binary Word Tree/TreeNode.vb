﻿Public Class TreeNode
    Public Value As String          ' the value to be stored at the current node
    Public LeftChild As TreeNode    ' the pointer to the left child node
    Public RightChild As TreeNode   ' the pointer to the right child node
    Public WordCount As Integer = 1
End Class
